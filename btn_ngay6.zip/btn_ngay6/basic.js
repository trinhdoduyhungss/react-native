function openNav() {
    document.getElementById("mySidenav").style.width = "550px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}

window.onscroll = function() {scrollFunction()};

function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("home").style.background = "#ec6d48";
        document.getElementById("home").style.color = "white";
        var a = new Date().getDate();
        var b = new Date().getMonth();
        var c = new Date().getFullYear()
        document.getElementById("today").innerHTML= "Today 's : "+ a +" "+ b +" "+ c;  
        var i = 1;
        var y = 7; 
        var output="<span>";     
        for (y; i < y; y--) {
            var d = new Date().getDate()+8;
            output +="<p> The next day "+" "+ [d-[y]] +"</p>";
        }
        output += "</span>";
        document.getElementById("day").innerHTML= output;
    } else {        
        document.getElementById("home").style=document.getElementsByClassName("group_a").style;
    }
}